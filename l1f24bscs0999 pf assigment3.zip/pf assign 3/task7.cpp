#include<iostream>
using namespace std;

void productrating() {

    int product[5][10];

    for (int i = 0; i < 5;i++) {

        for (int j = 0; j < 10; j++) {
            cout << "enter rating (1-5) of product  " << i + 1 << " by user " << j + 1 << endl;
            cin >> product[i][j];
            if (product[i][j] < 1 || product[i][j]>5) {
                cout << "invalid rating" << endl;
            }

        }
    }
    int perfectrating = 0;
    int min = 99999;
    int minindex = -1;

    for (int i = 0; i < 5;i++) {
        float sum = 0.0;
       
        for (int j = 0; j < 10; j++) {
            sum += product[i][j];
            if (product[i][j] == 5) {
                perfectrating++;
            }
        }
        float avg = sum / 10;
        if (avg < min) {
            min = avg;
            minindex = i;
        }
        cout << "average of product " << i + 1 << " is : " << avg << endl;
        cout << perfectrating << " users gives product"<< i+1<<"perfect rating" << endl;
        
    }
    cout << "worst avgerage prduct is  " << minindex + 1 << endl;
}
int main() {

    productrating();

    return 0;
}