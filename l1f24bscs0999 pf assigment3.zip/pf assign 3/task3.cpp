#include<iostream>
using namespace std;
void hospitalrecord() {
	char patient[5][7];
	cout << "enter patient status(s for statbel,c for critical and r for recoverd )" << endl;
	for (int i = 0;i < 5;i++) {
		for (int j = 0;j < 7;j++) {
			cout << "patient " << i + 1 << " over day  " << j + 1 << endl;
			cin >> patient[i][j];
			if (patient[i][j] != 's' && patient[i][j] != 'c' && patient[i][j] != 'r' && patient[i][j] != 'S' && patient[i][j] != 'C' && patient[i][j] != 'R') {
				cout << "invalid status input" << endl;
			}
		}
	}
	int stablecount = 0;
	int criticalcount = 0;
	int recoverdcount = 0;
	for (int i = 0;i < 5;i++) {
		for (int j = 0;j < 7;j++) {
			if(patient[i][j] == 's' || patient[i][j] == 'S') {
				stablecount++;
			}
			else if (patient[i][j] == 'c' ||patient[i][j] == 'C') {
				criticalcount++;
			}
			else if (patient[i][j] == 'r' || patient[i][j] == 'R') {
				recoverdcount++;
			}
		}
	}
	cout << "the number of stable patients are :" << stablecount << endl;
	cout << "the number of critical patients are :" << criticalcount << endl;
	cout << "the number of recoverd patients are :" << recoverdcount << endl;

	
	for (int i = 0;i < 5;i++) {
		int crticalstateday = 0;
		for (int j = 0;j < 7;j++) {
			if (patient[i][j] == 'c' || patient[i][j] == 'C') {
				crticalstateday++;
			}
		}
		cout << "the patient " << i + 1 << "remain in critical state for days " << crticalstateday << endl;
	}
	
}
int main() {

	hospitalrecord();
	return 0;

}