#include<iostream>
using namespace std;
void print() {
	int a[10][5];

	for (int i = 0;i < 10;i++) {
		for (int j = 0;j < 5;j++) {
			cout << "Enter student" << i + 1 << "marks of subject " << j + 1 << endl;
			cin >> a[i][j];
		}
	}
	for (int i = 0;i < 10;i++) {
		for (int j = 0;j < 5;j++) {
			cout << "the Marks of student " << i + 1 << " of subject " << j + 1 << " = " << a[i][j];

		}
		cout << endl;
	}
	int topstu = 1;
	int max = -1;
	char grade;
	float avg = 0.0;
	for (int i = 0;i < 10;i++) {
		float sum = 0.0;
		for (int j = 0;j < 5;j++) {
			sum += a[i][j];
		}
		avg = sum / 5;
		if (max < avg) {
			max = avg;
			topstu = i + 1;
					if (avg <= 100 && avg >= 90) {
						grade = 'A';
					}
					else if (avg < 90 && avg >= 80) {
						grade = 'B';
					}
					else if (avg < 80 && avg >= 70) {
						grade = 'C';
					}
					else if (avg < 70 && avg >= 60) {
						grade = 'D';
					}
					else {
						grade = 'F';
					}
		}
		cout << "the average of student" << i + 1 << " is " << avg << endl;
		cout << "the grade is " << grade << endl;
	}
	cout << "the maximum average is"<<max<< " of student " << topstu <<endl;
	}
int main() {
	
	print();
 }