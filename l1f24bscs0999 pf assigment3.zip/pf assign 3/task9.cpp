#include<iostream>
using namespace std;

void factory() {

    float defect[3][7];

    for (int i = 0; i < 3;i++) {

        for (int j = 0; j < 7; j++) {
            cout << "enter defect percentage of shift " << i + 1 << " over day " << j + 1 << endl;
            cin >> defect[i][j];
        }
    }
    float criticalshift = 0.0;
    int index = -1;
    for (int i = 0; i < 3;i++) {
        float rowsum = 0.0;
        
        for (int j = 0; j < 7; j++) {
            rowsum += defect[i][j];
        }
        float rowavg = rowsum / 7;
        if (rowavg > 10.0) {
            criticalshift = rowavg;
            index = i;
        }
        cout << "the avgerage defect percentage per shift " << i + 1 << " is : " << rowavg << endl;
    }
    cout << "critical shift is shift" << index + 1 << " with defects " << criticalshift << endl;
    
   
    for (int j = 0; j < 7;j++) {
        float colsum = 0.0;
        for (int i = 0; i < 3; i++) {
            colsum += defect[i][j];
        }
            float colavg = colsum / 3;
            cout << "the avgerage defect percentage per day  " << j + 1 << " is : " << colavg << endl;
    }
}
int main() {

    factory();

    return 0;
}