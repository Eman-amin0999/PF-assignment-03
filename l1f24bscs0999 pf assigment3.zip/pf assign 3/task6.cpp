#include<iostream>
using namespace std;
void flightrecord() {
    char flight[6][4];
   
    for (int i = 0; i < 6 ;i++) {

        for (int j = 0; j < 4; j++) {
            cout << "book seat( B or E ) row " << i + 1 <<" colmn "<<j+1<< endl;
            cin >> flight[i][j];

        }
    }
    int availablecount = 0;
    for (int i = 0; i < 6;i++) {

        for (int j = 0; j < 4; j++) {
            if (flight[i][j] == 'E' || flight[i][j] == 'e') {
                availablecount++;
            }
        }
    }
    cout << "the available seat are " << availablecount << endl;
    int max = -9999;
    int maxindex = -1;
    for (int i = 0; i < 6;i++) {
        int rowsum = 0;

        for (int j = 0; j < 4; j++) {
            if (flight[i][j] == 'E' || flight[i][j] == 'e') {
                rowsum++;
                if (rowsum > max) {
                    max = rowsum;
                    maxindex = i;
                }
            }
        }
    }
    cout << "the maximum availabel seats are: " << max << " at row " << maxindex+1 << endl;
}
int main() {

    flightrecord();

    return 0;
}