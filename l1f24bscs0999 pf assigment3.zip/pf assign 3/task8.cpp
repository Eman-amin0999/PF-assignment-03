#include<iostream>
using namespace std;

void library() {

    char book[5][5];

    for (int i = 0; i < 5;i++) {

        for (int j = 0; j < 5; j++) {
            cout << "enter shelves " << i + 1 << " book status " << j + 1 << endl;
            cin >>book[i][j];
            if (book[i][j] != 'i' && book[i][j] != 'm' && book[i][j] != 'a' && book[i][j] != 'A' && book[i][j] != 'I' && book[i][j] != 'M') {
                cout << "invalid status input" << endl;
            }
        }
    }
    int Acount = 0;
    int Mcount = 0;
    int Icount = 0;

    int maxmissing = -9999;
    int index = -1;

    for (int i = 0; i < 5;i++) {
        for (int j = 0; j < 5; j++) {
             if (book[i][j] == 'i' || book[i][j] == 'I') {
                Icount++;
             }
             else  if (book[i][j] == 'a' || book[i][j] == 'A') {
                    Acount++;
            
             }
             else  if (book[i][j] == 'm' || book[i][j] == 'M') {
                    Mcount++;
             }
                else {
                    cout<<"invalid status"<<endl;
                }
             if (Mcount > maxmissing) {
                 maxmissing = Mcount;
                 index = i;
             }
        }
    }
    cout << "the number of availavle books are: " << Acount << endl;
    cout << "the number of issued books are: " << Icount << endl;
    cout << "the number of missing books are: " << Mcount << endl;
    cout << "shelve with highest missing count is " << index + 1 << endl;
}
int main() {

    library();

    return 0;
}