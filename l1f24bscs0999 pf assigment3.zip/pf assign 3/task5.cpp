#include<iostream>
using namespace std;
void quiz() {
    int arr[6][4];
    int total[6] = { 0 };
    for (int i = 0;i < 6;i++) {
      
        for (int j = 0;j < 4;j++) {
            cout << "enter team " << i + 1 << " score of round " << j + 1 <<endl;
            cin >> arr[i][j];
            total[i] += arr[i][j];
        }
    }
    for (int i = 0;i < 6;i++) {
        cout << "team " << i + 1 << "total score is : " << total[i] << endl;
    }
        int max = -99999;
        int maxindex = -1;
        int secmax = -99999;
        int secmaxindex = -1;
        for (int i = 0;i < 6;i++) {
            for (int j = 0;j < 4;j++) {
                if (total[i] > max) {
                    secmax = max;
                    secmaxindex = maxindex;
                    max = total[i];
                    maxindex = i;
                }
                else if (total[i] > secmax && total[i] != max) {
                    secmax = total[i];
                    secmaxindex = i;
                }
            }

        }
    cout << "the winner team is "<< maxindex+1 <<" and score is " << max << endl;
    cout << "the runner up team is"<< secmaxindex +1 << " and score is " << secmax << endl;
    bool found = false;
    for (int i = 0;i < 6;i++) {
        for (int j = 0;j < 4;j++) {
            if (arr[i][j] <= 10) {
                cout << "team " << i + 1 << "score is " << arr[i][j] << " in round " << j + 1 << endl;
                found = true;
               
            }
        }
    }
    if (!found) {
        cout << "no team has less then 10 score" << endl;
    }
    
}
int main() {

    quiz();
    return 0;
}