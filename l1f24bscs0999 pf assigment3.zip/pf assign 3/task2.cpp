#include<iostream>
using namespace std;
void input() {
	int arr[4][7];
	for (int i = 0;i < 4;i++) {
		for (int j = 0;j < 7;j++) {
			cout << "enter item " << i+1 << "  day" << j+1 << " sales" << endl;
			cin >> arr[i][j];
		}
	}
	int totalmax = -1;
	int maxitem = -1;
	for (int i = 0;i < 4;i++) {
		int totalsalesperitem = 0;
			for (int j = 0;j < 7;j++) {
				
				totalsalesperitem += arr[i][j];
				
		    }
			if (totalmax < totalsalesperitem) {
				totalmax = totalsalesperitem;
				maxitem = i + 1;
			}
			cout << "total sale per item " << i+1<<" is " << totalsalesperitem << endl;
	}
	     cout << "the most sold item oeverall is " <<maxitem << endl;

	int max = -999999;
	int day = -1;

	for (int j = 0;j < 7;j++) {
		int totalsalesperday = 0;
		for (int i = 0;i < 4;i++) {

			totalsalesperday += arr[i][j];
			
		}
		if (totalsalesperday > max) {
			max = totalsalesperday;
			day = j + 1;
		}
		cout << "total sale of all item per day " << j + 1 <<" is " << totalsalesperday << endl;
	}
	
	cout << " the highest total sales is " << max << " at day " << day << endl;
}
int main() {
	
	input();
}