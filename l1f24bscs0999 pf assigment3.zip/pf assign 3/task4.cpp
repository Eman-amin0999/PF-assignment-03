#include<iostream>
using namespace std;
void temprecord() {
    float temp[5][5];
    for (int i = 0;i < 5;i++) {

        for (int j = 0;j < 5;j++) {
            cout << "enter zone " << i + 1 << " spot/location " << j + 1 << " temperture" << endl;
            cin >> temp[i][j];

        }
    }
    for (int i = 0;i < 5;i++) {
        float sum = 0.0;
        for (int j = 0;j < 5;j++) {
            sum += temp[i][j];
        }
        float avg = sum / 5;
        cout << "the average of zone " << i + 1 << " is " << avg << endl;
    }
    int max = -9999;
    int maxindex = -1;
    int min = 99999;
    int minindex = -1;
    for (int i = 0;i < 5;i++) {

        for (int j = 0;j < 5;j++) {
            if (temp[i][j] > max) {
                max = temp[i][j];
                maxindex = i;
            }
            else if (temp[i][j] < min) {
                min = temp[i][j];
                minindex = i;
            }
        }
    }
        cout << "the extrem hot spot is " << maxindex + 1 << " temperature is " << max << endl;
        cout << "the extrem cold spot is " << minindex + 1 << " temperature is " << min << endl;
}
int main() {

    temprecord();

    return 0;
}