#include<iostream>
using namespace std;
void electionresult() {
	int election[4][6];
	for (int i = 0;i < 4;i++) {
		for (int j = 0;j < 6;j++) {
			cout << "enter candidate " << i + 1 << "votes of polling station no: " << j + 1 << endl;
			cin >> election[i][j];
		}
	}
	int max = -99999;
	int index = -1;
	cout << "total votes per candidates :" << endl;
	for (int i = 0;i < 4;i++) {
		int totalvotespercandidates = 0;
		
		for (int j = 0;j < 6;j++) {
			totalvotespercandidates += election[i][j];
			if (totalvotespercandidates > max) {
				max = totalvotespercandidates;
				index = i;
			}
		}
		cout << " candidate " << i + 1 << ": " << totalvotespercandidates << endl;
	}
	cout << "the winner is candidate " << index + 1 << " with votes are: " << max << endl;
	cout << "total votes per polling station are:" << endl;

	int lessvote = 0;
	int lessindex = -1;
	for (int j = 0;j < 6;j++) {
		int totalvotesperpollingstation = 0;
		for (int i = 0;i < 4;i++) {
			totalvotesperpollingstation += election[i][j];
			if (totalvotesperpollingstation < 100) {
				lessvote = totalvotesperpollingstation;
				lessindex = i;
			}
		}
		cout << " polling station " << j + 1 << " : " << totalvotesperpollingstation << endl;
	}
	cout << "the polling station  " << lessindex + 1 << "has voters less then 100" << endl;
}


int main() {

	electionresult();
	return 0;

 }